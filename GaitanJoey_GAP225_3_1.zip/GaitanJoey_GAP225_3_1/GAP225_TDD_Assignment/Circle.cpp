#include "Vector2.h"
#include "Circle.h"

const float kPi = 3.14f;

Circle::Circle(Vector2 center, Vector2 point)
	: m_center { center }
	, m_point { point }
	{
		//
	}

float Circle::GetRadius()
{
	return Vector2::Distance(m_center, m_point);
}

float Circle::GetDiameter()
{
	return (GetRadius() * 2);
}

float Circle::GetCircumference()
{
	return (GetRadius() * 2 * Circle::kPi);
}

float Circle::GetArea()
{
	return (kPi * Vector2::Squared(GetRadius()));
}


int Circle::CircleIntersections(Circle circle)
{

	float circleCentersDistance = Vector2::Distance(m_center, circle.GetCenter());
	float radiusOfThisCircle = GetRadius();
	float radiusOfOtherCircle = circle.GetRadius();

	
	
	
	// If the two circles touch but do not intersect one another.
	if (circleCentersDistance == radiusOfThisCircle + radiusOfOtherCircle)
	{
		return 0;
	}
	// neither circle touches or intersects one another.
	else if (circleCentersDistance < radiusOfThisCircle + radiusOfOtherCircle)
	{
		return 1;
	}
	// Both circles overlap one another.
	else if (circleCentersDistance > radiusOfThisCircle + radiusOfOtherCircle)
	{
		return 2;
	}
}
