#pragma once
#include "Vector2.h"

class Triangle
{
private:
	Vector2 m_a;
	Vector2 m_b;
	Vector2 m_c;
public:
	Triangle(Vector2 vector1, Vector2 vector2, Vector2 vector3);

	// Get Length of the side of triangle.
	float GetSideLength(int side);

	// Get the perimeter of the triangle.
	float GetPerimeter();

	// Get the Area of the triangle.
	float GetArea();
};

