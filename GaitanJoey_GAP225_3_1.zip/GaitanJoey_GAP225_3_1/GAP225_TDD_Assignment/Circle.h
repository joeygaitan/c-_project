#pragma once
#include "Vector2.h"

class Circle
{
private:
	Vector2 m_center;
	Vector2 m_point;
public:
	static const float kPi;

	Circle(Vector2 center, Vector2 point);

	Vector2 GetCenter() { return m_center; }

	Vector2 GetPoint() { return m_point; }

	// Gets the radius of the circle by finding the distance between the center and the point.
	float GetRadius();

	// Gets the Diameter by multiplying the radius by two.
	float GetDiameter();

	// Gets the Circumference by multiplying the 
	float GetCircumference();

	// Get the area of a circle using pie * r squared
	float GetArea();

	// Find if the circle intersects  with any other circles
	int CircleIntersections(Circle circle);
};

