#include "Triangle.h"
#include "Vector2.h"

Triangle::Triangle(Vector2 vector1, Vector2 vector2, Vector2 vector3) 
	: m_a { vector1 }
	, m_b { vector2 }
	, m_c { vector3 }
	{
		// 
	}

float Triangle::GetSideLength(int side)
{
	switch (side)
	{
		case 0:
			Vector2::Distance(m_a, m_b);
			break;
		case 1:
			Vector2::Distance(m_b, m_c);
			break;
		case 2:
			Vector2::Distance(m_a, m_c);
			break;
		default:
			break;
	}
}

float Triangle::GetPerimeter()
{
	return (GetSideLength(0) + GetSideLength(1) + GetSideLength(2));
}

float Triangle::GetArea()
{
	// half of the triangle's perimeter
	// formula for a triangle with you knowing the sides is sqrtf(halfprimeter * (halfPerimeter * sideOneLength) * (halfPerimeter * sideTwoLength) * (halfPerimeter * sideThreeLength)));
	float halfPerimeter = (GetPerimeter() / 2.0f);


	float sideZeroLength = GetSideLength(0);
	float sideTwoLength = GetSideLength(1);
	float sideThreeLength = GetSideLength(2);

	return (sqrtf(halfPerimeter * (halfPerimeter - sideZeroLength) * (halfPerimeter - sideTwoLength) * (halfPerimeter - sideThreeLength)));
}