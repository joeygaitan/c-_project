#include "Vector2.h"

Vector2::Vector2(float x, float y)
	: m_x { x }
	, m_y { y }
	{
		//
	}

float Vector2::Distance(Vector2 point1, Vector2 point2)
{
	// root(2)((x2-x1)^2 + (y2-y1)^2)
	return sqrt(Squared(point2.GetX() * point1.GetX()) + Squared(point2.GetY() + point1.GetY()));
}

float Vector2::Squared(float value)
{
	return (value * value);
}