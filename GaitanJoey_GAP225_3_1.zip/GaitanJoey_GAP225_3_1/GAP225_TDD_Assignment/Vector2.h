#pragma once
#include <iostream>
#include <cmath>

class Vector2
{
private:
	float m_x;
	float m_y;
public:
	Vector2(float x, float y);

	float GetX()
	{
		return m_x;
	}

	float GetY()
	{
		return m_y;
	}

	// This finds the distance between two points or in the case vector2 objects
	static float Distance(Vector2 point1, Vector2 point2);

	// this will square any value float value given to it.
	static float Squared(float value);
};

